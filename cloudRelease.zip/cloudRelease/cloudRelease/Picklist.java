public class Picklist
{ 
    private OrderLine[] orderItems;
    
    public Picklist(OrderLine[] items)
    {
        orderItems = items;
    }
    
    public void getOrderLines(Picklist p)
    {
        //
    }
}